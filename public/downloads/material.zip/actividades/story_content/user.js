function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6PNKsKJpT2Q":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

